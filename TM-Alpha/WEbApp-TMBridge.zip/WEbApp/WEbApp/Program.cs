using Archipelago.MultiClient.Net;
using Archipelago.MultiClient.Net.Enums;
using Archipelago.MultiClient.Net.MessageLog.Messages;
using Archipelago.MultiClient.Net.Models;
using Archipelago.MultiClient.Net.Packets;
using System.Net.Http;
using System.Reflection.Metadata;
using System.Text.Json.Serialization;
using System.Xml.Linq;
using static System.Net.Mime.MediaTypeNames;
using mshtml;
using HtmlAgilityPack;
using Newtonsoft.Json;

var builder = WebApplication.CreateSlimBuilder(args);

string server = "localhost";
int port = 59967;
string username = "CidolfusTM";
string password = "";

builder.Services.ConfigureHttpJsonOptions(options =>
{
    options.SerializerOptions.TypeInfoResolverChain.Insert(0, AppJsonSerializerContext.Default);
});

var app = builder.Build();
MessageHandler message = new MessageHandler();
message.ItemToSend.Add("TestItem");
message.MessageToSend.Add("TestMessage");


var sampleTodos = new Todo[] {
    new(1, "Walk the dog"),
    new(2, "Do the dishes", DateOnly.FromDateTime(DateTime.Now)),
    new(3, "Do the laundry", DateOnly.FromDateTime(DateTime.Now.AddDays(1))),
    new(4, "Clean the bathroom"),
    new(5, "Clean the car", DateOnly.FromDateTime(DateTime.Now.AddDays(2)))
};

var todosApi = app.MapGroup("/todos");
todosApi.MapGet("/", () => sampleTodos);
todosApi.MapGet("/{id}", (int id) =>
    sampleTodos.FirstOrDefault(a => a.Id == id) is { } todo
        ? Results.Ok(todo)
        : Results.NotFound());

var testApi = app.MapGroup("/APConnect");
testApi.MapGet("/", () =>
{
    var session = ArchipelagoSessionFactory.CreateSession(server, port);
    session.MessageLog.OnMessageReceived += message.OnMessageReceived;
    session.Items.ItemReceived += message.OnItemReceived;
    LoginResult result = session.TryConnectAndLogin("Trackmania 2020", username, ItemsHandlingFlags.AllItems,new Version(2,1), requestSlotData: true);
    var loginSuccess = (LoginSuccessful)result;
    var entries = loginSuccess.SlotData.Select(d =>
        string.Format("\"{0}\": \"{1}\"", d.Key, d.Value));
    string jret = "{" + string.Join(",", entries) + "}";
    /*
    string ret = "";
    for(int i=1;i<=25;i++)
        ret += "\"AP-Main-" + i + "\": " + i + ",\r\n";
    jret = ret;*/
    return jret;
});

// devrait �tre un post  theoriquement
var MessageToServer = app.MapGroup("/Message");
MessageToServer.MapGet("/", (string urlEncodedString) =>
{
    var session = ArchipelagoSessionFactory.CreateSession(server, port);
    LoginResult result = session.TryConnectAndLogin("Trackmania 2020", username, ItemsHandlingFlags.AllItems, new Version(2, 1), requestSlotData: true);
    var loginSuccess = (LoginSuccessful)result;
    session.Socket.SendPacket(new SayPacket() { Text = urlEncodedString });
});

var RetrieveServer = app.MapGroup("/Retrieve");
RetrieveServer.MapGet("/", () =>
{
    var session = ArchipelagoSessionFactory.CreateSession(server, port);
    LoginResult result = session.TryConnectAndLogin("Trackmania 2020", username, ItemsHandlingFlags.AllItems, new Version(2, 1), requestSlotData: true);

    string ret = "{\"Message\":{" + string.Join(",", message.MessageToSend )  + "},\"Items\":{" + string.Join(",", message.ItemToSend ) + "}}";
    message.MessageToSend.Clear();
    message.ItemToSend.Clear();
    return ret;
});

RetrieveServer.MapGet("/AllItems", () =>
{
    var session = ArchipelagoSessionFactory.CreateSession(server, port);
    LoginResult result = session.TryConnectAndLogin("Trackmania 2020", username, ItemsHandlingFlags.AllItems, new Version(2, 1), requestSlotData: true);
    var loginSuccess = (LoginSuccessful)result;
    Thread.Sleep(500);
    List<long> ItemReceived = session.Items.AllItemsReceived.Select(c => c.Item).ToList();
    List<uint> LocationChecked = session.Locations.AllLocationsChecked.Select(c => ((uint)c)).ToList();

    //string ret = "[{\"Items\":{" + string.Join(",", session.Items.AllItemsReceived.Select(c=>c.Item).ToList()) + "}}]";
    string ret = string.Join("\",\"", ItemReceived);
    var alc = string.Join("\",\"", LocationChecked);
    return "{\"Items\":[\"" + ret + "\"], \"Checked\":[\"" + alc + "\"]" + "}";
    //" ret + "|" + alc;
});

var Checked = app.MapGroup("/Checked");
Checked.MapGet("/", (int locationId) =>
{
    var session = ArchipelagoSessionFactory.CreateSession(server, port);
    LoginResult result = session.TryConnectAndLogin("Trackmania 2020", username, ItemsHandlingFlags.AllItems, new Version(2, 1), requestSlotData: true);
    string locName = session.Locations.GetLocationNameFromId(locationId);
    session.Locations.CheckedLocationsUpdated += Locations_CheckedLocationsUpdated;
    session.Locations.CompleteLocationChecks(locationId); 
    return "Checked " + locationId + " named " + locName;
});

void Locations_CheckedLocationsUpdated(System.Collections.ObjectModel.ReadOnlyCollection<long> newCheckedLocations)
{
    //throw new NotImplementedException();
}

app.Run();

public record Todo(int Id, string? Title, DateOnly? DueBy = null, bool IsComplete = false);

[JsonSerializable(typeof(Todo[]))]
internal partial class AppJsonSerializerContext : JsonSerializerContext
{

}

public class MessageHandler
{
    public List<string> MessageToSend = new List<string>();
    public List<string> ItemToSend = new List<string>();

    public void OnMessageReceived(LogMessage message)
    {
        MessageToSend.Add(message.ToString());
    }
    public void OnItemReceived(Archipelago.MultiClient.Net.Helpers.ReceivedItemsHelper helper)
    {
        NetworkItem ni = helper.DequeueItem();

        string name = helper.GetItemName(ni.Item);

        int locName = (int)ni.Item;
        ItemToSend.Add("" +locName);
    }
}