from BaseClasses import Location, Dict, NamedTuple, Set, Optional, List, TypedDict
# from .data.mappack import MAPPACK_JSON

location_table = {
    "AP-Main-1": 1,
    "AP-Main-2": 2,
    "AP-Main-3": 3,
    "AP-Main-4": 4,
    "AP-Main-5": 5,
    "AP-Main-6": 6,
    "AP-Main-7": 7,
    "AP-Main-8": 8,
    "AP-Main-9": 9,
    "AP-Main-10": 10,
    "AP-Main-11": 11,
    "AP-Main-12": 12,
    "AP-Main-13": 13,
    "AP-Main-14": 14,
    "AP-Main-15": 15,
    "AP-Main-16": 16,
    "AP-Main-17": 17,
    "AP-Main-18": 18,
    "AP-Main-19": 19,
    "AP-Main-20": 20,
    "AP-Main-21": 21,
    "AP-Main-22": 22,
    "AP-Main-23": 23,
    "AP-Main-24": 24,
    "AP-Main-25": 25
}
