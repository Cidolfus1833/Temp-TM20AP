# Trackmania 2020

## What does randomization do to this game?

Every track are both items and checks. The next available map is always random.

## What does another world's item look like in Trackmania 2020?

They look like the gold or AT medal. Reaching the medal, sends item to other world. When someone find a TM2020 items, you get acces to a new map.

## Is there another mode?

For the current iteration, no. Only the RPG Like mode exist, which consist in completing maps to get more maps.

## What is the long term plan?

TMNF support.
Medal as a check mode (potentialy 4 checks per maps). Even if this game is "arcade", there's no outside effect. So buff or debuff or not possible outside how to complete a map. A debuff could be apply on the "next" map, forcing you to get Gold instead of silver.
Other game mode, not sure yet.