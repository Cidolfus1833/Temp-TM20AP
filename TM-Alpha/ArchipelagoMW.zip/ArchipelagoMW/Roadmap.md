## TM script
- class Location (80+%, je sais pas si je dois ajouter)
- gameloop (fichier interne pour jouer sans AP => minimalement, je veux AP, pas un RMC)
- faire les menue #2 et #3 (hidden est fait, reste Main et Pack)
- Entete du menu (x/y map de fait) 100%
- Checkbox pour restreindre la liste (100%)
- centraliser les requete Get et Post
- Menu pour afficher les messages
- GET "Item", "Message"
- POST "Check", "Message"
- (Message: Je peux envoyer les messages par GET, la, il me reste a recevoir la liste des messages)
- Cleanup les warning (fait, mais peut en avoir de nouveau)

# Step 2
- Beautification du menu (icône, gauche droite au lieu de liste, auto hide sur nouvelle piste)



## AngelBridge
- Session persistante (malgré restless)
- Accepter le GET "Item"
- Accepter le POST "Checked" (traiter comme GET pour l'instant)



## Archipelago world
- Items
- Locations
- Basic give & takes
